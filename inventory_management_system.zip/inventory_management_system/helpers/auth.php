
<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function require_login()
{
    if (!isset($_SESSION['user_id'])) {
        header('Location: /inventory_management_system/public/login.php');
        exit;
    }
}

function require_role($roles)
{
    require_login();

    if (!in_array($_SESSION['role'] ?? '', $roles, true)) {
        http_response_code(403);
        exit('Akses ditolak! Kamu tidak memiliki izin membuka halaman ini.');
    }
}

function logout()
{
    // Kosongkan seluruh data session.
    $_SESSION = [];

    // Hapus cookie session jika digunakan.
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    // Hancurkan session.
    session_destroy();

    // Kembali ke halaman login.
    header('Location: /inventory_management_system/public/login.php');
    exit;
}
