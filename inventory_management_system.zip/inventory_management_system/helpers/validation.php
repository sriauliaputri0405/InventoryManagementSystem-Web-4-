
<?php

function is_required($value)
{
    return trim((string) $value) !== '';
}

function is_valid_price($value)
{
    return is_numeric($value) && (float) $value >= 0;
}

function is_valid_quantity($value)
{
    $quantity = filter_var($value, FILTER_VALIDATE_INT);

    return $quantity !== false && $quantity >= 0;
}

function is_valid_id($value)
{
    $id = filter_var($value, FILTER_VALIDATE_INT);

    return $id !== false && $id > 0;
}

function is_valid_sku($value)
{
    return preg_match('/^[A-Za-z0-9_-]+$/', trim((string) $value)) === 1;
}

function is_valid_username($value)
{
    return preg_match('/^[A-Za-z0-9_]{3,30}$/', trim((string) $value)) === 1;
}
