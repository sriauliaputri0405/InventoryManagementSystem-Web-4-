<?php
require_once '../../helpers/auth.php';
require_once '../../config/database.php';

require_login();

$message = '';

$products = $pdo->query(
    "SELECT id, sku, name, stock
     FROM products
     ORDER BY name ASC"
)->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = filter_input(
        INPUT_POST,
        'product_id',
        FILTER_VALIDATE_INT
    );

    $quantity = filter_input(
        INPUT_POST,
        'quantity',
        FILTER_VALIDATE_INT
    );

    if (!$product_id || !$quantity || $quantity < 1) {
        $message = 'Pilih produk dan masukkan jumlah minimal 1.';
    } else {
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare(
                "SELECT stock FROM products WHERE id = ? FOR UPDATE"
            );
            $stmt->execute([$product_id]);
            $product = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$product) {
                throw new RuntimeException('Produk tidak ditemukan.');
            }

            if ($quantity > (int)$product['stock']) {
                throw new RuntimeException(
                    'Stok tidak mencukupi. Stok tersedia: ' .
                    (int)$product['stock']
                );
            }

            $stmt = $pdo->prepare(
                "UPDATE products SET stock = stock - ? WHERE id = ?"
            );
            $stmt->execute([$quantity, $product_id]);

            $stmt = $pdo->prepare(
                "INSERT INTO stock_movements
                 (product_id, user_id, type, quantity)
                 VALUES (?, ?, 'OUT', ?)"
            );
            $stmt->execute([
                $product_id,
                $_SESSION['user_id'],
                $quantity
            ]);

            $pdo->commit();

            header('Location: history.php');
            exit;

        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log('Barang keluar gagal: ' . $e->getMessage());

            $message = $e instanceof RuntimeException
                ? $e->getMessage()
                : 'Transaksi gagal disimpan. Periksa data database.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Barang Keluar - GlowMart</title>
</head>
<body>

<h1>GlowMart</h1>
<h2>Barang Keluar</h2>

<p><a href="../dashboard.php">← Kembali ke Dashboard</a></p>

<?php if ($message !== ''): ?>
    <p><?= htmlspecialchars($message) ?></p>
<?php endif; ?>

<form method="POST">
    <label>Produk</label><br>
    <select name="product_id" required>
        <option value="">-- Pilih Produk --</option>

        <?php foreach ($products as $product): ?>
            <option value="<?= (int)$product['id'] ?>">
                <?= htmlspecialchars($product['sku'] . ' - ' . $product['name']) ?>
                (Stok: <?= (int)$product['stock'] ?>)
            </option>
        <?php endforeach; ?>
    </select>

    <br><br>

    <label>Jumlah Barang Keluar</label><br>
    <input type="number" name="quantity" min="1" required>

    <br><br>

    <label>Keterangan</label><br>
    <textarea rows="4" cols="35"
        placeholder="Contoh: Penjualan produk"
        disabled></textarea>

    <p>Keterangan belum disimpan ke database.</p>

    <button type="submit">Simpan Barang Keluar</button>
</form>

</body>
</html>

