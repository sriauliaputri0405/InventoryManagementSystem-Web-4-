
<?php

require_once '../../helpers/auth.php';
require_once '../../config/database.php';

require_login();

$stmt = $pdo->query("
    SELECT
        stock_movements.id,
        products.sku,
        products.name AS product_name,
        users.username,
        stock_movements.type,
        stock_movements.quantity,
        stock_movements.created_at
    FROM stock_movements
    JOIN products
        ON stock_movements.product_id = products.id
    JOIN users
        ON stock_movements.user_id = users.id
    ORDER BY stock_movements.id DESC
");

$movements = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Riwayat Transaksi - GlowMart</title>
</head>

<body>

    <h1>GlowMart</h1>

    <h2>Riwayat Transaksi Stok</h2>

    <a href="../dashboard.php">← Kembali ke Dashboard</a>

    <br><br>

    <table border="1" cellpadding="10">

        <tr>
            <th>No.</th>
            <th>SKU</th>
            <th>Nama Produk</th>
            <th>Jenis Transaksi</th>
            <th>Jumlah</th>
            <th>Petugas</th>
            <th>Waktu</th>
        </tr>

        <?php if (empty($movements)): ?>

            <tr>
                <td colspan="7">Belum ada transaksi.</td>
            </tr>

        <?php else: ?>

            <?php foreach ($movements as $movement): ?>

                <tr>
                    <td>
                        <?= htmlspecialchars($movement['id']) ?>
                    </td>

                    <td>
                        <?= htmlspecialchars($movement['sku']) ?>
                    </td>

                    <td>
                        <?= htmlspecialchars($movement['product_name']) ?>
                    </td>

                    <td>
                        <?= $movement['type'] === 'IN'
                            ? 'Barang Masuk'
                            : 'Barang Keluar' ?>
                    </td>

                    <td>
                        <?= htmlspecialchars($movement['quantity']) ?>
                    </td>

                    <td>
                        <?= htmlspecialchars($movement['username']) ?>
                    </td>

                    <td>
                        <?= htmlspecialchars($movement['created_at']) ?>
                    </td>
                </tr>

            <?php endforeach; ?>

        <?php endif; ?>

    </table>

</body>
</html>