<?php
session_start();

require_once '../config/database.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare(
        "SELECT * FROM users WHERE username = ? LIMIT 1"
    );
    $stmt->execute([$username]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password_hash'])) {
        session_regenerate_id(true);

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];

        header('Location: dashboard.php');
        exit;
    } else {
        $message = 'Username atau password salah!';
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - GlowMart</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #f4edff, #e8dcfb);
            color: #35294b;
        }

        .login-card {
            width: 100%;
            max-width: 420px;
            background: white;
            padding: 36px;
            border-radius: 20px;
            box-shadow: 0 12px 35px #593a801a;
        }

        .logo {
            width: 66px;
            height: 66px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0 auto 18px;
            background: #eee5fc;
            border-radius: 18px;
            font-size: 32px;
        }

        h1 {
            margin: 0;
            text-align: center;
            color: #6c4ab6;
            font-size: 28px;
        }

        .subtitle {
            margin: 10px 0 28px;
            text-align: center;
            color: #81788f;
            font-size: 14px;
            line-height: 1.6;
        }

        label {
            display: block;
            margin: 16px 0 8px;
            font-size: 14px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 13px;
            border: 1px solid #ddd4ed;
            border-radius: 9px;
            font-size: 14px;
            outline: none;
        }

        input:focus {
            border-color: #8b68cb;
            box-shadow: 0 0 0 3px #eee7fa;
        }

        button {
            width: 100%;
            margin-top: 24px;
            padding: 14px;
            border: none;
            border-radius: 9px;
            background: #7652bd;
            color: white;
            font-size: 15px;
            font-weight: bold;
            cursor: pointer;
        }

        button:hover {
            background: #60409f;
        }

        .error {
            padding: 12px;
            margin-bottom: 18px;
            border-radius: 8px;
            background: #fff0f0;
            color: #b42332;
            font-size: 14px;
        }

        .footer {
            margin-top: 24px;
            text-align: center;
            color: #968da4;
            font-size: 12px;
        }
    </style>
</head>

<body>
    <div class="login-card">
        <div class="logo">🛍️</div>

        <h1>GlowMart</h1>

        <p class="subtitle">
            Inventory Management System<br>
            Silakan login untuk melanjutkan.
        </p>

        <?php if ($message !== ''): ?>
            <div class="error">
                <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <label for="username">Username</label>
            <input
                type="text"
                id="username"
                name="username"
                placeholder="Masukkan username"
                autocomplete="username"
                required
            >

            <label for="password">Password</label>
            <input
                type="password"
                id="password"
                name="password"
                placeholder="Masukkan password"
                autocomplete="current-password"
                required
            >

            <button type="submit">Login</button>
        </form>

        <div class="footer">
            &copy; <?= date('Y') ?> GlowMart
        </div>
    </div>
</body>
</html>
