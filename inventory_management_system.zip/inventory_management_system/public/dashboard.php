
<?php
require_once '../helpers/auth.php';

// Proses logout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    $submittedToken = $_POST['csrf_token'] ?? '';
    $sessionToken = $_SESSION['csrf_token'] ?? '';

    if (
        !is_string($submittedToken) ||
        !is_string($sessionToken) ||
        $sessionToken === '' ||
        !hash_equals($sessionToken, $submittedToken)
    ) {
        http_response_code(403);
        exit('Permintaan logout tidak valid. Muat ulang halaman dan coba lagi.');
    }

    logout();
}

require_login();

// Buat token keamanan untuk formulir logout
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

require_once '../config/database.php';

$username = htmlspecialchars(
    $_SESSION['username'] ?? 'Pengguna',
    ENT_QUOTES,
    'UTF-8'
);
$role = $_SESSION['role'] ?? 'staff';

// Statistik produk
$totalProducts = (int) $pdo->query(
    "SELECT COUNT(*) FROM products"
)->fetchColumn();

// Nilai seluruh persediaan
$inventoryValue = (float) $pdo->query(
    "SELECT COALESCE(SUM(stock * price), 0) FROM products"
)->fetchColumn();

// Produk dengan stok rendah
$lowStock = (int) $pdo->query(
    "SELECT COUNT(*) FROM products
     WHERE stock <= minimum_stock"
)->fetchColumn();

// Total stok masuk
$totalIncoming = (int) $pdo->query(
    "SELECT COALESCE(SUM(quantity), 0)
     FROM stock_movements WHERE type = 'IN'"
)->fetchColumn();

// Total stok keluar
$totalOutgoing = (int) $pdo->query(
    "SELECT COALESCE(SUM(quantity), 0)
     FROM stock_movements WHERE type = 'OUT'"
)->fetchColumn();

$page_title = 'Dashboard - GlowMart';
require_once '../views/header.php';
?>

<style>
    .logout-area {
        display: flex;
        justify-content: flex-end;
        margin-bottom: 16px;
    }

    .logout-button {
        background: #7652bd;
        color: white;
        border: none;
        padding: 11px 20px;
        border-radius: 9px;
        font-weight: 600;
        cursor: pointer;
    }

    .logout-button:hover {
        background: #6545a4;
    }

    .welcome {
        background: linear-gradient(135deg, #7652bd, #b69be8);
        color: white;
        padding: 28px;
        border-radius: 16px;
        margin-bottom: 24px;
    }

    .welcome h2 {
        margin-top: 0;
        margin-bottom: 8px;
    }

    .welcome p {
        margin-bottom: 0;
        line-height: 1.6;
    }

    .stats-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 16px;
        margin-bottom: 26px;
    }

    .stat-card {
        background: white;
        padding: 22px;
        border-radius: 14px;
        border: 1px solid #eee8f7;
        box-shadow: 0 4px 14px #38205c0b;
    }

    .stat-icon {
        font-size: 25px;
        margin-bottom: 12px;
    }

    .stat-card p {
        color: #777085;
        margin: 0 0 8px;
        font-size: 14px;
    }

    .stat-card h3 {
        color: #6545a4;
        margin: 0;
        font-size: 25px;
        overflow-wrap: anywhere;
    }

    .section-title {
        margin: 0 0 18px;
        color: #35294b;
    }

    .menu-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 16px;
    }

    .menu-card {
        display: block;
        background: white;
        padding: 22px;
        border: 1px solid #eee8f7;
        border-radius: 14px;
        text-decoration: none;
        color: #35294b;
        box-shadow: 0 4px 14px #38205c0b;
        transition: transform 0.2s, box-shadow 0.2s;
    }

    .menu-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 20px #38205c18;
    }

    .menu-card .menu-icon {
        font-size: 30px;
        margin-bottom: 12px;
    }

    .menu-card h3 {
        margin: 0 0 8px;
        font-size: 17px;
    }

    .menu-card p {
        margin: 0;
        color: #777085;
        font-size: 13px;
        line-height: 1.5;
    }

    .menu-card .arrow {
        display: block;
        text-align: right;
        color: #7652bd;
        margin-top: 14px;
        font-size: 20px;
    }

    .low-stock-note {
        padding: 15px 18px;
        margin-bottom: 24px;
        border-radius: 10px;
        background: #fff6e8;
        color: #80551a;
        border: 1px solid #f4dfb8;
    }

    .dashboard-footer {
        text-align: center;
        color: #8b8498;
        font-size: 13px;
        margin: 30px 0 10px;
    }

    @media (max-width: 750px) {
        .stats-grid,
        .menu-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }
    }

    @media (max-width: 480px) {
        .stats-grid,
        .menu-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="logout-area">
    <form method="POST" action="dashboard.php">
        <input
            type="hidden"
            name="csrf_token"
            value="<?= htmlspecialchars(
                $_SESSION['csrf_token'],
                ENT_QUOTES,
                'UTF-8'
            ) ?>"
        >

        <button
            type="submit"
            name="logout"
            value="1"
            class="logout-button"
            onclick="return confirm('Yakin ingin logout?')"
        >
            ↪ Logout
        </button>
    </form>
</div>

<div class="welcome">
    <h2>Halo, <?= $username ?>! 👋</h2>

    <p>
        Selamat datang di GlowMart Inventory Management System.
        Kelola produk dan persediaan tokomu dengan lebih mudah.
    </p>

    <p>
        Role:
        <strong><?= htmlspecialchars(
            ucfirst($role),
            ENT_QUOTES,
            'UTF-8'
        ) ?></strong>
    </p>
</div>

<h2 class="section-title">Ringkasan Persediaan</h2>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon">📦</div>
        <p>Total Produk</p>
        <h3><?= number_format($totalProducts, 0, ',', '.') ?></h3>
    </div>

    <div class="stat-card">
        <div class="stat-icon">💰</div>
        <p>Nilai Persediaan</p>
        <h3>Rp <?= number_format($inventoryValue, 0, ',', '.') ?></h3>
    </div>

    <div class="stat-card">
        <div class="stat-icon">⚠️</div>
        <p>Stok Rendah</p>
        <h3><?= number_format($lowStock, 0, ',', '.') ?></h3>
    </div>

    <div class="stat-card">
        <div class="stat-icon">📥</div>
        <p>Total Stok Masuk</p>
        <h3><?= number_format($totalIncoming, 0, ',', '.') ?></h3>
    </div>

    <div class="stat-card">
        <div class="stat-icon">📤</div>
        <p>Total Stok Keluar</p>
        <h3><?= number_format($totalOutgoing, 0, ',', '.') ?></h3>
    </div>

    <div class="stat-card">
        <div class="stat-icon">🛍️</div>
        <p>Sistem</p>
        <h3>GlowMart</h3>
    </div>
</div>

<?php if ($lowStock > 0): ?>
    <div class="low-stock-note">
        ⚠️ Ada <?= number_format($lowStock, 0, ',', '.') ?>
        produk yang stoknya sudah mencapai batas minimum.
        Silakan periksa persediaan.
    </div>
<?php endif; ?>

<h2 class="section-title">Menu Utama</h2>

<div class="menu-grid">
    <a class="menu-card" href="products/index.php">
        <div class="menu-icon">📦</div>
        <h3>Daftar Produk</h3>
        <p>Lihat, cari, dan periksa data produk GlowMart.</p>
        <span class="arrow">→</span>
    </a>

    <?php if ($role === 'admin'): ?>
        <a class="menu-card" href="products/create.php">
            <div class="menu-icon">➕</div>
            <h3>Tambah Produk</h3>
            <p>Tambahkan produk baru ke dalam sistem.</p>
            <span class="arrow">→</span>
        </a>
    <?php endif; ?>

    <a class="menu-card" href="stock/incoming.php">
        <div class="menu-icon">📥</div>
        <h3>Stok Masuk</h3>
        <p>Catat penambahan stok produk.</p>
        <span class="arrow">→</span>
    </a>

    <a class="menu-card" href="stock/outgoing.php">
        <div class="menu-icon">📤</div>
        <h3>Stok Keluar</h3>
        <p>Catat pengurangan stok produk.</p>
        <span class="arrow">→</span>
    </a>

    <a class="menu-card" href="stock/history.php">
        <div class="menu-icon">📋</div>
        <h3>Riwayat Stok</h3>
        <p>Lihat catatan transaksi stok masuk dan keluar.</p>
        <span class="arrow">→</span>
    </a>
</div>

<div class="dashboard-footer">
    GlowMart Inventory Management System
</div>

</main>
</body>
</html>
