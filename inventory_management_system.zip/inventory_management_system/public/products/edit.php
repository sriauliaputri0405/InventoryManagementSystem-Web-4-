
<?php
require_once '../../helpers/auth.php';
require_role(['admin']);

require_once '../../config/database.php';
require_once '../../helpers/validation.php';
require_once '../../helpers/escape.php';

$message = '';
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    http_response_code(400);
    exit('ID produk tidak valid.');
}

// Ambil produk.
$stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
$stmt->execute([$id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    http_response_code(404);
    exit('Produk tidak ditemukan.');
}

// Ambil kategori dan supplier.
$categories = $pdo->query(
    'SELECT id, name FROM categories ORDER BY name ASC'
)->fetchAll(PDO::FETCH_ASSOC);

$suppliers = $pdo->query(
    'SELECT id, name FROM suppliers ORDER BY name ASC'
)->fetchAll(PDO::FETCH_ASSOC);

// Ambil relasi supplier yang sudah tersimpan.
$stmt = $pdo->prepare(
    'SELECT supplier_id, supplier_price
     FROM product_suppliers
     WHERE product_id = ?'
);
$stmt->execute([$id]);
$existingSupplierRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$supplierPrices = [];

foreach ($existingSupplierRows as $row) {
    $sid = (int) $row['supplier_id'];
    $supplierPrices[$sid] = $row['supplier_price'] === null
        ? ''
        : (string) $row['supplier_price'];
}

$selectedSupplierIds = array_map('intval', array_keys($supplierPrices));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sku = trim((string) ($_POST['sku'] ?? ''));
    $name = trim((string) ($_POST['name'] ?? ''));
    $category_id = $_POST['category_id'] ?? '';
    $price = $_POST['price'] ?? '';
    $minimum_stock = $_POST['minimum_stock'] ?? '';

    $rawSupplierIds = $_POST['supplier_ids'] ?? [];
    $rawSupplierPrices = $_POST['supplier_prices'] ?? [];

    $selectedSupplierIds = [];
    $supplierPrices = [];

    // Validasi format data supplier.
    if (!is_array($rawSupplierIds) || !is_array($rawSupplierPrices)) {
        $message = 'Data supplier tidak valid.';
        $rawSupplierIds = [];
        $rawSupplierPrices = [];
    }

    if ($message === '') {
        foreach ($rawSupplierIds as $rawId) {
            if (!is_scalar($rawId) || !is_valid_id($rawId)) {
                $message = 'Pilihan supplier tidak valid.';
                break;
            }

            $selectedSupplierIds[] = (int) $rawId;
        }
    }

    $selectedSupplierIds = array_values(
        array_unique($selectedSupplierIds)
    );

    if ($message === '') {
        foreach ($rawSupplierPrices as $sid => $supplierPrice) {
            if (
                !ctype_digit((string) $sid) ||
                !is_scalar($supplierPrice)
            ) {
                $message = 'Data harga supplier tidak valid.';
                break;
            }

            $supplierPrices[(int) $sid] =
                trim((string) $supplierPrice);
        }
    }

    // Validasi produk.
    if ($message === '') {
        if (
            !is_required($sku) ||
            !is_required($name) ||
            !is_required($category_id) ||
            !is_required($price) ||
            !is_required($minimum_stock)
        ) {
            $message = 'Semua kolom produk wajib diisi.';
        } elseif (
            !is_valid_sku($sku) ||
            strlen($sku) > 100 ||
            strlen($name) > 255 ||
            !is_valid_id($category_id) ||
            !is_valid_price($price) ||
            !is_valid_quantity($minimum_stock)
        ) {
            $message = 'Data tidak valid. Periksa SKU, nama, kategori, harga, dan minimum stok.';
        } elseif (
            count($selectedSupplierIds) !== count($rawSupplierIds)
        ) {
            $message = 'Pilihan supplier tidak valid.';
        }
    }

    // Pertahankan input yang dikirim jika validasi gagal.
    $product['sku'] = $sku;
    $product['name'] = $name;
    $product['category_id'] = $category_id;
    $product['price'] = $price;
    $product['minimum_stock'] = $minimum_stock;

    if ($message === '') {
        try {
            // Pastikan kategori tersedia.
            $categoryCheck = $pdo->prepare(
                'SELECT COUNT(*) FROM categories WHERE id = ?'
            );
            $categoryCheck->execute([(int) $category_id]);

            if (!(int) $categoryCheck->fetchColumn()) {
                $message = 'Kategori yang dipilih tidak ditemukan.';
            }

            // Pastikan supplier benar-benar tersedia.
            if ($message === '' && !empty($selectedSupplierIds)) {
                $placeholders = implode(
                    ',',
                    array_fill(0, count($selectedSupplierIds), '?')
                );

                $checkSuppliers = $pdo->prepare(
                    "SELECT id FROM suppliers WHERE id IN ($placeholders)"
                );
                $checkSuppliers->execute($selectedSupplierIds);

                $existingIds = array_map(
                    'intval',
                    $checkSuppliers->fetchAll(PDO::FETCH_COLUMN)
                );

                $compareIds = $selectedSupplierIds;
                sort($existingIds);
                sort($compareIds);

                if ($existingIds !== $compareIds) {
                    $message = 'Supplier yang dipilih tidak ditemukan.';
                }
            }

            // Harga hanya boleh diisi untuk supplier yang dipilih.
            if ($message === '') {
                foreach ($supplierPrices as $sid => $supplierPrice) {
                    if (
                        !in_array($sid, $selectedSupplierIds, true) &&
                        $supplierPrice !== ''
                    ) {
                        $message = 'Harga hanya boleh diisi untuk supplier yang dipilih.';
                        break;
                    }

                    if (
                        $supplierPrice !== '' &&
                        !is_valid_price($supplierPrice)
                    ) {
                        $message = 'Harga supplier harus berupa angka nol atau lebih.';
                        break;
                    }
                }
            }

            // Periksa SKU tidak dipakai produk lain.
            if ($message === '') {
                $check = $pdo->prepare(
                    'SELECT id FROM products WHERE sku = ? AND id != ?'
                );
                $check->execute([$sku, $id]);

                if ($check->fetch()) {
                    $message = 'SKU sudah digunakan produk lain.';
                }
            }

            if ($message === '') {
                $pdo->beginTransaction();

                // Perbarui data produk tanpa mengubah stok saat ini.
                $stmt = $pdo->prepare(
                    'UPDATE products
                     SET sku = ?, name = ?, category_id = ?,
                         price = ?, minimum_stock = ?
                     WHERE id = ?'
                );

                $stmt->execute([
                    $sku,
                    $name,
                    (int) $category_id,
                    (float) $price,
                    (int) $minimum_stock,
                    $id
                ]);

                // Perbarui relasi supplier dalam transaksi yang sama.
                $stmt = $pdo->prepare(
                    'DELETE FROM product_suppliers WHERE product_id = ?'
                );
                $stmt->execute([$id]);

                if (!empty($selectedSupplierIds)) {
                    $insertSupplier = $pdo->prepare(
                        'INSERT INTO product_suppliers
                         (product_id, supplier_id, supplier_price)
                         VALUES (?, ?, ?)'
                    );

                    foreach ($selectedSupplierIds as $sid) {
                        $supplierPrice = $supplierPrices[$sid] ?? '';

                        $insertSupplier->execute([
                            $id,
                            $sid,
                            $supplierPrice !== ''
                                ? (float) $supplierPrice
                                : null
                        ]);
                    }
                }

                $pdo->commit();

                header('Location: index.php');
                exit;
            }
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log($e->getMessage());

            if ($e->getCode() === '23000') {
                $message = 'SKU sudah digunakan atau relasi data tidak valid.';
            } else {
                $message = 'Perubahan gagal disimpan. Silakan coba lagi.';
            }
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log($e->getMessage());
            $message = 'Terjadi kesalahan saat memperbarui produk.';
        }
    }
}

$page_title = 'Edit Produk - GlowMart';
require_once '../../views/header.php';
?>

<style>
.back-link {
    display: inline-block;
    margin-bottom: 20px;
    color: #6545a4;
    text-decoration: none;
    font-size: 14px;
}
.page-heading {
    margin-bottom: 24px;
}
.page-heading h2 {
    margin: 0 0 8px;
    color: #35294b;
}
.page-heading p {
    margin: 0;
    color: #81788f;
    line-height: 1.6;
}
.form-card {
    max-width: 760px;
    margin: 0 auto 30px;
    padding: 30px;
    background: white;
    border: 1px solid #eee8f7;
    border-radius: 16px;
    box-shadow: 0 5px 18px #38205c0b;
}
.form-card h3 {
    margin: 0 0 8px;
    color: #6545a4;
}
.form-description {
    margin: 0 0 25px;
    color: #81788f;
    font-size: 14px;
}
.form-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 20px;
}
.form-group label {
    display: block;
    margin-bottom: 8px;
    color: #51416e;
    font-size: 14px;
    font-weight: 600;
}
.form-group input,
.form-group select {
    box-sizing: border-box;
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd4ed;
    border-radius: 9px;
    background: white;
    color: #35294b;
}
.form-message {
    margin-bottom: 20px;
    padding: 13px 15px;
    border-radius: 9px;
    background: #fff0f0;
    color: #b42332;
    font-size: 14px;
}
.stock-info {
    margin-top: 22px;
    padding: 16px;
    border-radius: 10px;
    background: #f5f0fd;
    color: #51416e;
    line-height: 1.7;
    font-size: 14px;
}
.supplier-section {
    grid-column: 1 / -1;
}
.supplier-list {
    border: 1px solid #e5dcf2;
    border-radius: 10px;
    padding: 12px;
}
.supplier-row {
    display: grid;
    grid-template-columns: 24px minmax(100px, 1fr) minmax(130px, 180px);
    gap: 10px;
    align-items: center;
    padding: 10px 0;
    border-bottom: 1px solid #f0ecf5;
}
.supplier-row:last-child {
    border-bottom: none;
}
.supplier-row input[type="checkbox"] {
    width: auto;
}
.supplier-row input[type="number"] {
    box-sizing: border-box;
    width: 100%;
    min-width: 0;
    padding: 10px;
    border: 1px solid #ddd4ed;
    border-radius: 8px;
}
.supplier-help {
    color: #81788f;
    font-size: 13px;
    line-height: 1.6;
}
.form-actions {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
    margin-top: 28px;
    padding-top: 22px;
    border-top: 1px solid #f0ecf5;
}
.btn {
    display: inline-block;
    padding: 12px 18px;
    border: 0;
    border-radius: 9px;
    font-weight: 600;
    font-size: 14px;
    text-decoration: none;
    cursor: pointer;
    text-align: center;
}
.btn-primary {
    background: #7652bd;
    color: white;
}
.btn-light {
    background: #eee8fa;
    color: #6545a4;
}
@media (max-width: 550px) {
    .form-card {
        padding: 20px;
    }
    .form-grid {
        grid-template-columns: 1fr;
    }
    .supplier-section {
        grid-column: auto;
    }
    .supplier-row {
        grid-template-columns: 22px minmax(70px, 1fr);
    }
    .supplier-row input[type="number"] {
        grid-column: 2;
    }
    .form-actions .btn {
        width: 100%;
    }
}
</style>

<a href="index.php" class="back-link">
    ← Kembali ke Daftar Produk
</a>

<div class="page-heading">
    <h2>Edit Produk ✏️</h2>
    <p>Perbarui informasi produk GlowMart dengan mudah.</p>
</div>

<div class="form-card">
    <h3>Informasi Produk</h3>
    <p class="form-description">
        Ubah data produk dan supplier di bawah ini, lalu simpan perubahan.
    </p>

    <?php if ($message !== ''): ?>
        <div class="form-message">
            <?= e($message) ?>
        </div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-grid">
            <div class="form-group">
                <label for="sku">SKU Produk *</label>
                <input
                    type="text"
                    id="sku"
                    name="sku"
                    maxlength="100"
                    value="<?= e($product['sku']) ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="name">Nama Produk *</label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    maxlength="255"
                    value="<?= e($product['name']) ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="category_id">Kategori *</label>
                <select id="category_id" name="category_id" required>
                    <option value="">-- Pilih Kategori --</option>
                    <?php foreach ($categories as $category): ?>
                        <option
                            value="<?= (int) $category['id'] ?>"
                            <?= (string) $product['category_id'] === (string) $category['id']
                                ? 'selected' : '' ?>
                        >
                            <?= e($category['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="price">Harga Jual (Rp) *</label>
                <input
                    type="number"
                    id="price"
                    name="price"
                    min="0"
                    step="any"
                    value="<?= e($product['price']) ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="minimum_stock">Minimum Stok *</label>
                <input
                    type="number"
                    id="minimum_stock"
                    name="minimum_stock"
                    min="0"
                    step="1"
                    value="<?= e($product['minimum_stock']) ?>"
                    required
                >
            </div>

            <div class="supplier-section">
                <h3>Supplier Produk</h3>
                <p class="supplier-help">
                    Centang supplier yang memasok produk ini. Kamu dapat
                    memilih lebih dari satu supplier. Harga supplier boleh
                    dikosongkan jika belum diketahui.
                </p>

                <div class="supplier-list">
                    <?php if (empty($suppliers)): ?>
                        <p>Belum ada supplier. Tambahkan supplier terlebih dahulu.</p>
                    <?php else: ?>
                        <?php foreach ($suppliers as $supplier): ?>
                            <?php
                            $sid = (int) $supplier['id'];
                            $isSelected = in_array(
                                $sid,
                                $selectedSupplierIds,
                                true
                            );
                            $supplierPrice = $supplierPrices[$sid] ?? '';
                            ?>
                            <div class="supplier-row">
                                <input
                                    type="checkbox"
                                    id="supplier_<?= $sid ?>"
                                    name="supplier_ids[]"
                                    value="<?= $sid ?>"
                                    <?= $isSelected ? 'checked' : '' ?>
                                >

                                <label for="supplier_<?= $sid ?>">
                                    <?= e($supplier['name']) ?>
                                </label>

                                <input
                                    type="number"
                                    name="supplier_prices[<?= $sid ?>]"
                                    min="0"
                                    step="0.01"
                                    placeholder="Harga supplier (Rp)"
                                    aria-label="Harga dari <?= e($supplier['name']) ?>"
                                    value="<?= e($supplierPrice) ?>"
                                >
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="stock-info">
            <strong>📦 Stok saat ini:</strong>
            <?= number_format((int) $product['stock'], 0, ',', '.') ?>
            <br>
            Stok tidak diubah dari halaman ini. Gunakan menu Stok Masuk atau
            Stok Keluar agar riwayat persediaan tercatat.
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">
                Simpan Perubahan
            </button>

            <a href="index.php" class="btn btn-light">Batal</a>
        </div>
    </form>
</div>

</main>
</body>
</html>
