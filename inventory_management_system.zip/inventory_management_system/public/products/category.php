
<?php
require_once '../../helpers/auth.php';
require_role(['admin']);
require_once '../../config/database.php';

$error = '';
$success = '';
$editCategory = null;

// Proses tambah, edit, dan hapus kategori
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
        $name = trim($_POST['name'] ?? '');

        if ($name === '') {
            $error = 'Nama kategori wajib diisi.';
        } elseif (mb_strlen($name) > 100) {
            $error = 'Nama kategori maksimal 100 karakter.';
        } else {
            try {
                if ($id && $id > 0) {
                    $stmt = $pdo->prepare(
                        'SELECT id FROM categories WHERE name = ? AND id <> ?'
                    );
                    $stmt->execute([$name, $id]);
                } else {
                    $stmt = $pdo->prepare(
                        'SELECT id FROM categories WHERE name = ?'
                    );
                    $stmt->execute([$name]);
                }

                if ($stmt->fetch()) {
                    $error = 'Nama kategori sudah digunakan.';
                } elseif ($id && $id > 0) {
                    $stmt = $pdo->prepare(
                        'UPDATE categories SET name = ? WHERE id = ?'
                    );
                    $stmt->execute([$name, $id]);
                    header('Location: category.php?status=updated');
                    exit;
                } else {
                    $stmt = $pdo->prepare(
                        'INSERT INTO categories (name) VALUES (?)'
                    );
                    $stmt->execute([$name]);
                    header('Location: category.php?status=added');
                    exit;
                }
            } catch (PDOException $e) {
                error_log($e->getMessage());
                $error = 'Kategori gagal disimpan. Periksa struktur tabel categories.';
            }
        }
    } elseif ($action === 'delete') {
        $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

        if (!$id || $id < 1) {
            $error = 'ID kategori tidak valid.';
        } else {
            try {
                $stmt = $pdo->prepare(
                    'SELECT COUNT(*) FROM products WHERE category_id = ?'
                );
                $stmt->execute([$id]);

                if ((int) $stmt->fetchColumn() > 0) {
                    $error = 'Kategori tidak dapat dihapus karena masih digunakan produk.';
                } else {
                    $stmt = $pdo->prepare(
                        'DELETE FROM categories WHERE id = ?'
                    );
                    $stmt->execute([$id]);

                    if ($stmt->rowCount() > 0) {
                        header('Location: category.php?status=deleted');
                        exit;
                    }

                    $error = 'Kategori tidak ditemukan.';
                }
            } catch (PDOException $e) {
                error_log($e->getMessage());
                $error = 'Kategori gagal dihapus.';
            }
        }
    }
}

// Ambil kategori untuk diedit
$editId = filter_input(INPUT_GET, 'edit', FILTER_VALIDATE_INT);

if ($editId && $editId > 0) {
    $stmt = $pdo->prepare(
        'SELECT id, name FROM categories WHERE id = ?'
    );
    $stmt->execute([$editId]);
    $editCategory = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$editCategory) {
        $error = 'Kategori yang ingin diedit tidak ditemukan.';
    }
}

// Ambil seluruh kategori
$stmt = $pdo->query(
    'SELECT c.id, c.name, COUNT(p.id) AS total_products
     FROM categories c
     LEFT JOIN products p ON p.category_id = c.id
     GROUP BY c.id, c.name
     ORDER BY c.name ASC'
);
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (isset($_GET['status'])) {
    $messages = [
        'added' => 'Kategori berhasil ditambahkan.',
        'updated' => 'Kategori berhasil diperbarui.',
        'deleted' => 'Kategori berhasil dihapus.'
    ];

    $success = $messages[$_GET['status']] ?? '';
}

$page_title = 'Kelola Kategori - GlowMart';
require_once '../../views/header.php';
?>

<style>
.category-panel {
    background: white;
    padding: 24px;
    border-radius: 14px;
    margin-bottom: 22px;
    border: 1px solid #e9e0f5;
}
.category-panel h2 {
    color: #35204f;
    margin-top: 0;
}
.category-form {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
    align-items: end;
}
.category-form input {
    flex: 1;
    min-width: 220px;
    padding: 11px;
    border: 1px solid #d8cbea;
    border-radius: 8px;
}
.category-button {
    background: #7952c7;
    color: white;
    border: none;
    border-radius: 8px;
    padding: 11px 16px;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
}
.category-cancel {
    background: #eee7f8;
    color: #6541a5;
}
.category-delete {
    background: #fff0f0;
    color: #c62828;
}
.category-table {
    width: 100%;
    border-collapse: collapse;
}
.category-table th,
.category-table td {
    text-align: left;
    padding: 13px 10px;
    border-bottom: 1px solid #eee7f5;
}
.category-table th {
    background: #eee7fa;
    color: #35204f;
}
.category-message {
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 16px;
}
.category-success {
    background: #e9f8ee;
    color: #18733a;
}
.category-error {
    background: #fff0f0;
    color: #b91c1c;
}
@media (max-width: 600px) {
    .category-table {
        font-size: 13px;
    }
    .category-table th,
    .category-table td {
        padding: 8px 5px;
    }
}
</style>

<div class="category-panel">
    <h2>Kelola Kategori</h2>
    <p>Tambah dan kelola kategori produk GlowMart.</p>

    <?php if ($success !== ''): ?>
        <div class="category-message category-success">
            <?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <?php if ($error !== ''): ?>
        <div class="category-message category-error">
            <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <h3><?= $editCategory ? 'Edit Kategori' : 'Tambah Kategori' ?></h3>

    <form method="POST" class="category-form">
        <input type="hidden" name="action" value="save">
        <input
            type="hidden"
            name="id"
            value="<?= (int) ($editCategory['id'] ?? 0) ?>"
        >

        <input
            type="text"
            name="name"
            maxlength="100"
            placeholder="Contoh: SKINCARE"
            value="<?= htmlspecialchars(
                $editCategory['name'] ?? ($_POST['name'] ?? ''),
                ENT_QUOTES,
                'UTF-8'
            ) ?>"
            required
        >

        <button type="submit" class="category-button">
            <?= $editCategory ? 'Simpan Perubahan' : 'Tambah Kategori' ?>
        </button>

        <?php if ($editCategory): ?>
            <a href="category.php" class="category-button category-cancel">
                Batal
            </a>
        <?php endif; ?>
    </form>
</div>

<div class="category-panel">
    <h2>Daftar Kategori</h2>

    <div style="overflow-x:auto;">
        <table class="category-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama Kategori</th>
                    <th>Jumlah Produk</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>
                <?php if (empty($categories)): ?>
                    <tr>
                        <td colspan="4">Belum ada kategori.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($categories as $category): ?>
                        <tr>
                            <td><?= (int) $category['id'] ?></td>
                            <td>
                                <?= htmlspecialchars(
                                    $category['name'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>
                            </td>
                            <td><?= (int) $category['total_products'] ?></td>
                            <td>
                                <a
                                    href="category.php?edit=<?= (int) $category['id'] ?>"
                                    style="color:#6541a5;"
                                >Edit</a>

                                <form
                                    method="POST"
                                    style="display:inline;"
                                    onsubmit="return confirm('Yakin ingin menghapus kategori ini?')"
                                >
                                    <input
                                        type="hidden"
                                        name="action"
                                        value="delete"
                                    >
                                    <input
                                        type="hidden"
                                        name="id"
                                        value="<?= (int) $category['id'] ?>"
                                    >
                                    <button
                                        type="submit"
                                        class="category-button category-delete"
                                        style="padding:5px 9px;margin-left:8px;"
                                    >Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <p style="margin-top:20px;">
        <a href="index.php" class="category-button category-cancel">
            Kembali ke Daftar Produk
        </a>
    </p>
</div>

</main>
</body>
</html>
