<?php
require_once '../../helpers/auth.php';
require_role(['admin']);
require_once '../../config/database.php';

// Penghapusan hanya boleh melalui tombol POST.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = false;

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare(
        'SELECT id, name FROM products WHERE id = ? FOR UPDATE'
    );
    $stmt->execute([$id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        $error = 'Produk tidak ditemukan.';
    } else {
        $stmt = $pdo->prepare(
            'SELECT COUNT(*) FROM stock_movements WHERE product_id = ?'
        );
        $stmt->execute([$id]);
        $hasHistory = (int) $stmt->fetchColumn() > 0;

        if ($hasHistory) {
            $error = 'Produk tidak dapat dihapus karena sudah memiliki riwayat transaksi stok.';
        } else {
            $stmt = $pdo->prepare(
                'DELETE FROM product_suppliers WHERE product_id = ?'
            );
            $stmt->execute([$id]);

            $stmt = $pdo->prepare(
                'DELETE FROM products WHERE id = ?'
            );
            $stmt->execute([$id]);

            $success = true;
        }
    }

    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log($e->getMessage());
    $error = 'Produk gagal dihapus. Periksa hubungan data produk, lalu coba lagi.';
}

$page_title = 'Hapus Produk - GlowMart';
require_once '../../views/header.php';
?>

<div class="panel">
    <h2>Hapus Produk</h2>

    <?php if ($success): ?>
        <p style="color: green;">
            Produk berhasil dihapus.
        </p>
    <?php else: ?>
        <p style="color: #b91c1c;">
            <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
        </p>
    <?php endif; ?>

    <a href="index.php">Kembali ke Daftar Produk</a>
</div>

</main>
</body>
</html>
