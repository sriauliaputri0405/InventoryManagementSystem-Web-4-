
<?php
require_once '../../helpers/auth.php';
require_role(['admin']);
require_once '../../config/database.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

    if ($action === 'save') {
        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $address = trim($_POST['address'] ?? '');

        if ($name === '') {
            $error = 'Nama supplier wajib diisi.';
        } elseif (mb_strlen($name) > 150) {
            $error = 'Nama supplier maksimal 150 karakter.';
        } elseif (mb_strlen($phone) > 30) {
            $error = 'Nomor telepon maksimal 30 karakter.';
        } else {
            try {
                if ($id && $id > 0) {
                    $stmt = $pdo->prepare(
                        'SELECT id FROM suppliers WHERE name = ? AND id <> ?'
                    );
                    $stmt->execute([$name, $id]);
                } else {
                    $stmt = $pdo->prepare(
                        'SELECT id FROM suppliers WHERE name = ?'
                    );
                    $stmt->execute([$name]);
                }

                if ($stmt->fetch()) {
                    $error = 'Nama supplier sudah terdaftar.';
                } elseif ($id && $id > 0) {
                    $stmt = $pdo->prepare(
                        'UPDATE suppliers
                         SET name = ?, phone = ?, address = ?
                         WHERE id = ?'
                    );
                    $stmt->execute([
                        $name,
                        $phone !== '' ? $phone : null,
                        $address !== '' ? $address : null,
                        $id
                    ]);

                    header('Location: supplier.php?status=updated');
                    exit;
                } else {
                    $stmt = $pdo->prepare(
                        'INSERT INTO suppliers (name, phone, address)
                         VALUES (?, ?, ?)'
                    );
                    $stmt->execute([
                        $name,
                        $phone !== '' ? $phone : null,
                        $address !== '' ? $address : null
                    ]);

                    header('Location: supplier.php?status=added');
                    exit;
                }
            } catch (PDOException $e) {
                error_log($e->getMessage());
                $error = 'Data supplier gagal disimpan.';
            }
        }
    } elseif ($action === 'delete') {
        if (!$id || $id < 1) {
            $error = 'ID supplier tidak valid.';
        } else {
            try {
                $stmt = $pdo->prepare(
                    'SELECT COUNT(*) FROM product_suppliers
                     WHERE supplier_id = ?'
                );
                $stmt->execute([$id]);

                if ((int) $stmt->fetchColumn() > 0) {
                    $error = 'Supplier tidak dapat dihapus karena masih terhubung dengan produk.';
                } else {
                    $stmt = $pdo->prepare(
                        'DELETE FROM suppliers WHERE id = ?'
                    );
                    $stmt->execute([$id]);

                    if ($stmt->rowCount() > 0) {
                        header('Location: supplier.php?status=deleted');
                        exit;
                    }

                    $error = 'Supplier tidak ditemukan.';
                }
            } catch (PDOException $e) {
                error_log($e->getMessage());
                $error = 'Supplier gagal dihapus.';
            }
        }
    }
}

$editSupplier = null;
$editId = filter_input(INPUT_GET, 'edit', FILTER_VALIDATE_INT);

if ($editId && $editId > 0) {
    $stmt = $pdo->prepare(
        'SELECT id, name, phone, address
         FROM suppliers WHERE id = ?'
    );
    $stmt->execute([$editId]);
    $editSupplier = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$editSupplier) {
        $error = 'Supplier tidak ditemukan.';
    }
}

$stmt = $pdo->query(
    'SELECT s.id, s.name, s.phone, s.address,
            COUNT(ps.product_id) AS total_products
     FROM suppliers s
     LEFT JOIN product_suppliers ps ON ps.supplier_id = s.id
     GROUP BY s.id, s.name, s.phone, s.address
     ORDER BY s.name ASC'
);
$suppliers = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (isset($_GET['status'])) {
    $messages = [
        'added' => 'Supplier berhasil ditambahkan.',
        'updated' => 'Supplier berhasil diperbarui.',
        'deleted' => 'Supplier berhasil dihapus.'
    ];

    $success = $messages[$_GET['status']] ?? '';
}

$page_title = 'Kelola Supplier - GlowMart';
require_once '../../views/header.php';
?>

<style>
.supplier-panel {
    background: white;
    padding: 24px;
    border-radius: 14px;
    margin-bottom: 22px;
    border: 1px solid #e9e0f5;
}
.supplier-panel h2 {
    color: #35204f;
    margin-top: 0;
}
.supplier-form {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 14px;
}
.supplier-form label {
    display: block;
    margin-bottom: 6px;
}
.supplier-form input,
.supplier-form textarea {
    box-sizing: border-box;
    width: 100%;
    padding: 11px;
    border: 1px solid #d8cbea;
    border-radius: 8px;
}
.supplier-form .full-width {
    grid-column: 1 / -1;
}
.supplier-button {
    background: #7952c7;
    color: white;
    border: none;
    border-radius: 8px;
    padding: 10px 15px;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
}
.supplier-cancel {
    background: #eee7f8;
    color: #6541a5;
}
.supplier-delete {
    background: #fff0f0;
    color: #c62828;
}
.supplier-table {
    width: 100%;
    border-collapse: collapse;
}
.supplier-table th,
.supplier-table td {
    padding: 12px 10px;
    text-align: left;
    border-bottom: 1px solid #eee7f5;
}
.supplier-table th {
    background: #eee7fa;
    color: #35204f;
}
.supplier-message {
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 16px;
}
.supplier-success {
    background: #e9f8ee;
    color: #18733a;
}
.supplier-error {
    background: #fff0f0;
    color: #b91c1c;
}
@media (max-width: 650px) {
    .supplier-form {
        grid-template-columns: 1fr;
    }
    .supplier-form .full-width {
        grid-column: auto;
    }
}
</style>

<div class="supplier-panel">
    <h2>Kelola Supplier</h2>
    <p>Tambah dan kelola data supplier GlowMart.</p>

    <?php if ($success !== ''): ?>
        <div class="supplier-message supplier-success">
            <?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <?php if ($error !== ''): ?>
        <div class="supplier-message supplier-error">
            <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <h3><?= $editSupplier ? 'Edit Supplier' : 'Tambah Supplier' ?></h3>

    <form method="POST" class="supplier-form">
        <input type="hidden" name="action" value="save">
        <input
            type="hidden"
            name="id"
            value="<?= (int) ($editSupplier['id'] ?? 0) ?>"
        >

        <div>
            <label for="name">Nama Supplier *</label>
            <input
                type="text"
                id="name"
                name="name"
                maxlength="150"
                value="<?= htmlspecialchars(
                    $editSupplier['name'] ?? '',
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>"
                required
            >
        </div>

        <div>
            <label for="phone">Nomor Telepon</label>
            <input
                type="text"
                id="phone"
                name="phone"
                maxlength="30"
                value="<?= htmlspecialchars(
                    $editSupplier['phone'] ?? '',
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>"
            >
        </div>

        <div class="full-width">
            <label for="address">Alamat</label>
            <textarea
                id="address"
                name="address"
                rows="3"
            ><?= htmlspecialchars(
                $editSupplier['address'] ?? '',
                ENT_QUOTES,
                'UTF-8'
            ) ?></textarea>
        </div>

        <div class="full-width">
            <button type="submit" class="supplier-button">
                <?= $editSupplier ? 'Simpan Perubahan' : 'Tambah Supplier' ?>
            </button>

            <?php if ($editSupplier): ?>
                <a href="supplier.php"
                   class="supplier-button supplier-cancel">
                    Batal
                </a>
            <?php endif; ?>
        </div>
    </form>
</div>

<div class="supplier-panel">
    <h2>Daftar Supplier</h2>

    <div style="overflow-x:auto;">
        <table class="supplier-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama Supplier</th>
                    <th>Telepon</th>
                    <th>Alamat</th>
                    <th>Produk Terhubung</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($suppliers)): ?>
                    <tr>
                        <td colspan="6">Belum ada supplier.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($suppliers as $supplier): ?>
                        <tr>
                            <td><?= (int) $supplier['id'] ?></td>
                            <td><?= htmlspecialchars(
                                $supplier['name'],
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?></td>
                            <td><?= htmlspecialchars(
                                $supplier['phone'] ?? '',
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?></td>
                            <td><?= htmlspecialchars(
                                $supplier['address'] ?? '',
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?></td>
                            <td><?= (int) $supplier['total_products'] ?></td>
                            <td>
                                <a
                                    href="supplier.php?edit=<?= (int) $supplier['id'] ?>"
                                    style="color:#6541a5;"
                                >Edit</a>

                                <form
                                    method="POST"
                                    style="display:inline;"
                                    onsubmit="return confirm('Yakin ingin menghapus supplier ini?')"
                                >
                                    <input type="hidden" name="action"
                                           value="delete">
                                    <input type="hidden" name="id"
                                           value="<?= (int) $supplier['id'] ?>">
                                    <button
                                        type="submit"
                                        class="supplier-button supplier-delete"
                                        style="padding:5px 9px;margin-left:8px;"
                                    >Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <p style="margin-top:20px;">
        <a href="index.php" class="supplier-button supplier-cancel">
            Kembali ke Daftar Produk
        </a>
    </p>
</div>

</main>
</body>
</html>
