
<?php
require_once '../../helpers/auth.php';
require_once '../../config/database.php';

require_login();

$role = $_SESSION['role'] ?? 'staff';

// SEARCH
$search = trim($_GET['search'] ?? '');

// FILTER KATEGORI
$category_id = $_GET['category_id'] ?? '';

// SORTING
$sort = $_GET['sort'] ?? 'name';
$direction = $_GET['direction'] ?? 'ASC';

$allowed_sort = [
    'name'  => 'products.name',
    'price' => 'products.price',
    'stock' => 'products.stock'
];

if (!array_key_exists($sort, $allowed_sort)) {
    $sort = 'name';
}

if (!in_array($direction, ['ASC', 'DESC'], true)) {
    $direction = 'ASC';
}

// PAGINATION
$page = max(1, (int) ($_GET['page'] ?? 1));
$per_page = 5;

// AMBIL KATEGORI
$categories = $pdo->query(
    "SELECT id, name FROM categories ORDER BY name ASC"
)->fetchAll(PDO::FETCH_ASSOC);

// MEMBUAT FILTER
$where = [];
$params = [];

if ($search !== '') {
    $where[] = "(products.name LIKE ? OR products.sku LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

if ($category_id !== '' && ctype_digit((string) $category_id)) {
    $where[] = "products.category_id = ?";
    $params[] = (int) $category_id;
}

$where_sql = '';

if (!empty($where)) {
    $where_sql = 'WHERE ' . implode(' AND ', $where);
}

// HITUNG PRODUK
$count_sql = "
    SELECT COUNT(*)
    FROM products
    $where_sql
";

$count_stmt = $pdo->prepare($count_sql);
$count_stmt->execute($params);
$total_products = (int) $count_stmt->fetchColumn();

$total_pages = max(1, (int) ceil($total_products / $per_page));
$page = min($page, $total_pages);
$offset = ($page - 1) * $per_page;

// AMBIL DATA PRODUK
$sql = "
    SELECT
        products.*,
        categories.name AS category_name
    FROM products
    JOIN categories
        ON products.category_id = categories.id
    $where_sql
    ORDER BY {$allowed_sort[$sort]} $direction
    LIMIT $per_page OFFSET $offset
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// PARAMETER PAGINATION
$query_params = [
    'search' => $search,
    'category_id' => $category_id,
    'sort' => $sort,
    'direction' => $direction
];

function productUrl(array $params, int $page): string
{
    $params['page'] = $page;
    return '?' . http_build_query($params);
}

$page_title = 'Daftar Produk - GlowMart';
require_once '../../views/header.php';
?>

<style>
.page-heading {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 14px;
    margin-bottom: 22px;
}

.page-heading h2 {
    margin: 0 0 7px;
    color: #35294b;
}

.page-heading p {
    margin: 0;
    color: #81788f;
    font-size: 14px;
}

.btn {
    display: inline-block;
    border: none;
    border-radius: 8px;
    padding: 11px 16px;
    text-decoration: none;
    font-size: 14px;
    cursor: pointer;
    font-weight: 600;
}

.btn-primary {
    background: #7652bd;
    color: white;
}

.btn-primary:hover {
    background: #60409f;
}

.btn-light {
    background: #eee8fa;
    color: #6545a4;
}

.filter-panel,
.table-panel {
    background: white;
    padding: 20px;
    border-radius: 13px;
    border: 1px solid #eee8f7;
    margin-bottom: 22px;
}

.filter-panel h3 {
    margin: 0 0 15px;
    font-size: 17px;
}

.filter-form {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 12px;
    align-items: end;
}

.filter-field label {
    display: block;
    font-size: 13px;
    color: #655b74;
    margin-bottom: 7px;
}

.filter-field input,
.filter-field select {
    width: 100%;
    min-width: 0;
    background: white;
    box-sizing: border-box;
}

.filter-actions {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.table-title {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
    margin-bottom: 15px;
}

.table-title h3 {
    margin: 0;
}

.table-title span {
    color: #81788f;
    font-size: 13px;
}

.table-scroll {
    overflow-x: auto;
}

.product-table {
    min-width: 720px;
    border-collapse: collapse;
    width: 100%;
}

.product-table th {
    background: #eee8fa;
    color: #51416e;
    font-size: 13px;
    white-space: nowrap;
}

.product-table th,
.product-table td {
    padding: 13px 12px;
    text-align: left;
    border-bottom: 1px solid #f0ecf5;
}

.product-table tbody tr:hover {
    background: #faf8ff;
}

.product-name {
    font-weight: 600;
    color: #35294b;
}

.sku-text {
    color: #81788f;
    font-size: 13px;
}

.category-badge {
    display: inline-block;
    background: #f0eafa;
    color: #6545a4;
    padding: 5px 9px;
    border-radius: 20px;
    font-size: 12px;
}

.stock-badge {
    display: inline-block;
    background: #e8f7ed;
    color: #237443;
    padding: 5px 9px;
    border-radius: 7px;
    font-weight: 600;
}

.stock-low {
    background: #fff0dd;
    color: #9a5b08;
}

.action-links {
    white-space: nowrap;
}

.action-links a,
.delete-link {
    text-decoration: none;
    font-size: 13px;
    font-weight: 600;
    margin-right: 8px;
}

.edit-link {
    color: #6545a4;
}

.delete-link {
    color: #c34250;
    border: 0;
    background: transparent;
    padding: 0;
    cursor: pointer;
    font-family: inherit;
}

.empty-state {
    text-align: center !important;
    padding: 35px !important;
    color: #81788f;
}

.empty-state div {
    font-size: 32px;
    margin-bottom: 10px;
}

.pagination {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;
    gap: 8px;
    margin-top: 20px;
}

.pagination a,
.pagination span {
    padding: 9px 13px;
    border-radius: 8px;
    text-decoration: none;
    background: #f0eafa;
    color: #6545a4;
    font-size: 13px;
}

.pagination .current {
    background: #7652bd;
    color: white;
}

.back-link {
    display: inline-block;
    margin-bottom: 18px;
    text-decoration: none;
    color: #6545a4;
    font-size: 14px;
}

@media (max-width: 850px) {
    .filter-form {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

@media (max-width: 500px) {
    .filter-form {
        grid-template-columns: 1fr;
    }

    .page-heading {
        align-items: stretch;
    }

    .page-heading .btn {
        text-align: center;
    }

    .table-panel,
    .filter-panel {
        padding: 14px;
    }
}
</style>

<a class="back-link" href="../dashboard.php">
    ← Kembali ke Dashboard
</a>

<div class="page-heading">
    <div>
        <h2>Daftar Produk 📦</h2>
        <p>Kelola dan pantau persediaan produk GlowMart.</p>
    </div>

    <?php if ($role === 'admin'): ?>
        <a class="btn btn-primary" href="create.php">
            + Tambah Produk
        </a>
    <?php endif; ?>
</div>

<div class="filter-panel">
    <h3>🔎 Cari dan Filter Produk</h3>

    <form method="GET" class="filter-form">
        <div class="filter-field">
            <label for="search">Nama produk atau SKU</label>
            <input
                type="text"
                id="search"
                name="search"
                placeholder="Cari produk..."
                value="<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>"
            >
        </div>

        <div class="filter-field">
            <label for="category_id">Kategori</label>
            <select id="category_id" name="category_id">
                <option value="">Semua Kategori</option>

                <?php foreach ($categories as $category): ?>
                    <option
                        value="<?= (int) $category['id'] ?>"
                        <?= (string) $category_id === (string) $category['id'] ? 'selected' : '' ?>
                    >
                        <?= htmlspecialchars($category['name'], ENT_QUOTES, 'UTF-8') ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="filter-field">
            <label for="sort">Urutkan berdasarkan</label>
            <select id="sort" name="sort">
                <option value="name" <?= $sort === 'name' ? 'selected' : '' ?>>
                    Nama produk
                </option>
                <option value="price" <?= $sort === 'price' ? 'selected' : '' ?>>
                    Harga
                </option>
                <option value="stock" <?= $sort === 'stock' ? 'selected' : '' ?>>
                    Stok
                </option>
            </select>
        </div>

        <div class="filter-field">
            <label for="direction">Urutan</label>
            <select id="direction" name="direction">
                <option value="ASC" <?= $direction === 'ASC' ? 'selected' : '' ?>>
                    Naik (A-Z / kecil-besar)
                </option>
                <option value="DESC" <?= $direction === 'DESC' ? 'selected' : '' ?>>
                    Turun (Z-A / besar-kecil)
                </option>
            </select>
        </div>

        <div class="filter-actions">
            <button class="btn btn-primary" type="submit">
                Terapkan
            </button>

            <a class="btn btn-light" href="index.php">Reset</a>
        </div>
    </form>
</div>

<div class="table-panel">
    <div class="table-title">
        <h3>Data Produk</h3>
        <span>
            <?= number_format($total_products, 0, ',', '.') ?> produk ditemukan
        </span>
    </div>

    <div class="table-scroll">
        <table class="product-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Produk</th>
                    <th>Kategori</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>
                <?php if (empty($products)): ?>
                    <tr>
                        <td colspan="6" class="empty-state">
                            <div>📭</div>
                            Tidak ada produk yang cocok dengan pencarian.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($products as $product): ?>
                        <?php
                        $stock = (int) $product['stock'];
                        $minimumStock = (int) $product['minimum_stock'];
                        $isLowStock = $stock <= $minimumStock;
                        ?>

                        <tr>
                            <td><?= (int) $product['id'] ?></td>

                            <td>
                                <div class="product-name">
                                    <?= htmlspecialchars($product['name'], ENT_QUOTES, 'UTF-8') ?>
                                </div>
                                <div class="sku-text">
                                    SKU:
                                    <?= htmlspecialchars($product['sku'], ENT_QUOTES, 'UTF-8') ?>
                                </div>
                            </td>

                            <td>
                                <span class="category-badge">
                                    <?= htmlspecialchars($product['category_name'], ENT_QUOTES, 'UTF-8') ?>
                                </span>
                            </td>

                            <td>
                                Rp <?= number_format((float) $product['price'], 0, ',', '.') ?>
                            </td>

                            <td>
                                <span class="stock-badge <?= $isLowStock ? 'stock-low' : '' ?>">
                                    <?= number_format($stock, 0, ',', '.') ?>
                                </span>
                            </td>

                            <td class="action-links">
                                <?php if ($role === 'admin'): ?>
                                    <a
                                        class="edit-link"
                                        href="edit.php?id=<?= (int) $product['id'] ?>"
                                    >
                                        Edit
                                    </a>

                                    <form
                                        action="delete.php"
                                        method="POST"
                                        style="display:inline;"
                                        onsubmit="return confirm('Yakin ingin menghapus produk ini?')"
                                    >
                                        <input
                                            type="hidden"
                                            name="id"
                                            value="<?= (int) $product['id'] ?>"
                                        >

                                        <button type="submit" class="delete-link">
                                            Hapus
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <span class="sku-text">Lihat saja</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if ($total_products > 0): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="<?= htmlspecialchars(productUrl($query_params, $page - 1), ENT_QUOTES, 'UTF-8') ?>">
                    ← Sebelumnya
                </a>
            <?php endif; ?>

            <span class="current">
                Halaman <?= $page ?> dari <?= $total_pages ?>
            </span>

            <?php if ($page < $total_pages): ?>
                <a href="<?= htmlspecialchars(productUrl($query_params, $page + 1), ENT_QUOTES, 'UTF-8') ?>">
                    Berikutnya →
                </a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

</main>
</body>
</html>