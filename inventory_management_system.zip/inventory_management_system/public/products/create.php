
<?php
require_once '../../helpers/auth.php';
require_role(['admin']);

require_once '../../config/database.php';
require_once '../../helpers/validation.php';
require_once '../../helpers/escape.php';

$message = '';
$sku = '';
$name = '';
$category_id = '';
$price = '';
$stock = '';
$minimum_stock = '';
$supplier_ids = [];
$supplier_prices = [];

$categories = $pdo->query(
    "SELECT id, name FROM categories ORDER BY name ASC"
)->fetchAll(PDO::FETCH_ASSOC);

$suppliers = $pdo->query(
    "SELECT id, name FROM suppliers ORDER BY name ASC"
)->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sku = trim((string) ($_POST['sku'] ?? ''));
    $name = trim((string) ($_POST['name'] ?? ''));
    $category_id = $_POST['category_id'] ?? '';
    $price = $_POST['price'] ?? '';
    $stock = $_POST['stock'] ?? '';
    $minimum_stock = $_POST['minimum_stock'] ?? '';

    $rawSupplierIds = $_POST['supplier_ids'] ?? [];
    $rawSupplierPrices = $_POST['supplier_prices'] ?? [];

    if (!is_array($rawSupplierIds)) {
        $rawSupplierIds = [];
        $message = 'Pilihan supplier tidak valid.';
    }

    if (!is_array($rawSupplierPrices)) {
        $rawSupplierPrices = [];
        $message = 'Data harga supplier tidak valid.';
    }

    foreach ($rawSupplierIds as $rawId) {
        if (is_scalar($rawId) && is_valid_id($rawId)) {
            $supplier_ids[] = (int) $rawId;
        } else {
            $message = 'Pilihan supplier tidak valid.';
            break;
        }
    }

    $supplier_ids = array_values(array_unique($supplier_ids));

    foreach ($rawSupplierPrices as $sid => $supplierPrice) {
        if (
            ctype_digit((string) $sid) &&
            is_scalar($supplierPrice)
        ) {
            $supplier_prices[(int) $sid] =
                trim((string) $supplierPrice);
        } else {
            $message = 'Data harga supplier tidak valid.';
            break;
        }
    }

    if ($message === '') {
        if (
            !is_required($sku) ||
            !is_required($name) ||
            !is_required($category_id) ||
            !is_required($price) ||
            !is_required($stock) ||
            !is_required($minimum_stock)
        ) {
            $message = 'Semua kolom produk wajib diisi.';
        } elseif (
            !is_valid_sku($sku) ||
            strlen($sku) > 100 ||
            strlen($name) > 255 ||
            !is_valid_id($category_id) ||
            !is_valid_price($price) ||
            !is_valid_quantity($stock) ||
            !is_valid_quantity($minimum_stock)
        ) {
            $message = 'Data tidak valid. Periksa SKU, nama, kategori, harga, dan stok.';
        } elseif (
            count($supplier_ids) !== count($rawSupplierIds)
        ) {
            $message = 'Pilihan supplier tidak valid.';
        } else {
            try {
                // Periksa kategori.
                $categoryCheck = $pdo->prepare(
                    'SELECT COUNT(*) FROM categories WHERE id = ?'
                );
                $categoryCheck->execute([(int) $category_id]);

                if (!(int) $categoryCheck->fetchColumn()) {
                    $message = 'Kategori yang dipilih tidak ditemukan.';
                }

                // Periksa supplier yang dipilih.
                if ($message === '' && !empty($supplier_ids)) {
                    $placeholders = implode(
                        ',',
                        array_fill(0, count($supplier_ids), '?')
                    );

                    $checkSuppliers = $pdo->prepare(
                        "SELECT id FROM suppliers WHERE id IN ($placeholders)"
                    );
                    $checkSuppliers->execute($supplier_ids);

                    $existingIds = array_map(
                        'intval',
                        $checkSuppliers->fetchAll(PDO::FETCH_COLUMN)
                    );

                    $selectedIds = $supplier_ids;
                    sort($existingIds);
                    sort($selectedIds);

                    if ($existingIds !== $selectedIds) {
                        $message = 'Supplier yang dipilih tidak ditemukan.';
                    }
                }

                // Periksa harga supplier.
                if ($message === '') {
                    foreach ($supplier_prices as $sid => $sp) {
                        if (
                            !in_array($sid, $supplier_ids, true) &&
                            $sp !== ''
                        ) {
                            $message = 'Harga hanya boleh diisi untuk supplier yang dipilih.';
                            break;
                        }

                        if ($sp !== '' && !is_valid_price($sp)) {
                            $message = 'Harga supplier harus berupa angka nol atau lebih.';
                            break;
                        }
                    }
                }

                if ($message === '') {
                    $pdo->beginTransaction();

                    // Pastikan SKU belum digunakan.
                    $skuCheck = $pdo->prepare(
                        'SELECT COUNT(*) FROM products WHERE sku = ?'
                    );
                    $skuCheck->execute([$sku]);

                    if ((int) $skuCheck->fetchColumn() > 0) {
                        throw new RuntimeException(
                            'SKU sudah digunakan. Gunakan SKU lain.'
                        );
                    }

                    // Simpan produk.
                    $stmt = $pdo->prepare(
                        'INSERT INTO products
                         (category_id, sku, name, price, stock, minimum_stock)
                         VALUES (?, ?, ?, ?, ?, ?)'
                    );

                    $stmt->execute([
                        (int) $category_id,
                        $sku,
                        $name,
                        (float) $price,
                        (int) $stock,
                        (int) $minimum_stock
                    ]);

                    $productId = (int) $pdo->lastInsertId();

                    // Simpan relasi produk dengan supplier.
                    if (!empty($supplier_ids)) {
                        $linkSupplier = $pdo->prepare(
                            'INSERT INTO product_suppliers
                             (product_id, supplier_id, supplier_price)
                             VALUES (?, ?, ?)'
                        );

                        foreach ($supplier_ids as $sid) {
                            $sp = $supplier_prices[$sid] ?? '';

                            $linkSupplier->execute([
                                $productId,
                                $sid,
                                $sp !== '' ? (float) $sp : null
                            ]);
                        }
                    }

                    $pdo->commit();

                    header('Location: index.php');
                    exit;
                }
            } catch (RuntimeException $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                $message = $e->getMessage();
            } catch (PDOException $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                error_log($e->getMessage());

                if ($e->getCode() === '23000') {
                    $message = 'SKU sudah digunakan atau relasi data tidak valid.';
                } else {
                    $message = 'Produk gagal disimpan. Silakan coba lagi.';
                }
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                error_log($e->getMessage());
                $message = 'Terjadi kesalahan saat menyimpan produk.';
            }
        }
    }
}

$page_title = 'Tambah Produk - GlowMart';
require_once '../../views/header.php';
?>

<style>
.form-card {
    max-width: 760px;
    margin: 0 auto 30px;
    background: white;
    padding: 30px;
    border-radius: 16px;
    border: 1px solid #eee8f7;
    box-shadow: 0 5px 18px #38205c0b;
}
.form-card h2,
.form-card h3 {
    color: #6545a4;
}
.form-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 18px;
}
.form-group label {
    display: block;
    margin-bottom: 7px;
    color: #51416e;
    font-weight: 600;
    font-size: 14px;
}
.form-group input,
.form-group select {
    box-sizing: border-box;
    width: 100%;
    padding: 11px;
    border: 1px solid #ddd4ed;
    border-radius: 9px;
    background: white;
}
.supplier-list {
    border: 1px solid #e5dcf2;
    border-radius: 10px;
    padding: 12px;
}
.supplier-row {
    display: grid;
    grid-template-columns: 24px minmax(100px, 1fr) minmax(130px, 180px);
    gap: 10px;
    align-items: center;
    padding: 10px 0;
    border-bottom: 1px solid #f0ecf5;
}
.supplier-row:last-child {
    border-bottom: none;
}
.supplier-row input[type="checkbox"] {
    width: auto;
}
.supplier-row input[type="number"] {
    box-sizing: border-box;
    width: 100%;
    min-width: 0;
    padding: 10px;
    border: 1px solid #ddd4ed;
    border-radius: 9px;
}
.full-width {
    grid-column: 1 / -1;
}
.help-text {
    display: block;
    margin-top: 6px;
    color: #81788f;
    font-size: 12px;
}
.form-message {
    background: #fff0f0;
    color: #b42332;
    padding: 13px;
    border-radius: 9px;
    margin-bottom: 18px;
}
.form-actions {
    display: flex;
    gap: 12px;
    margin-top: 24px;
    flex-wrap: wrap;
}
.btn {
    display: inline-block;
    padding: 12px 18px;
    border: 0;
    border-radius: 9px;
    font-weight: 600;
    text-decoration: none;
    cursor: pointer;
}
.btn-primary {
    background: #7652bd;
    color: white;
}
.btn-light {
    background: #eee8fa;
    color: #6545a4;
}
.back-link {
    display: inline-block;
    margin-bottom: 20px;
    color: #6545a4;
    text-decoration: none;
}
@media (max-width: 600px) {
    .form-grid {
        grid-template-columns: 1fr;
    }
    .full-width {
        grid-column: auto;
    }
    .form-card {
        padding: 18px;
    }
    .supplier-row {
        grid-template-columns: 22px minmax(70px, 1fr);
    }
    .supplier-row input[type="number"] {
        grid-column: 2;
    }
}
</style>

<a href="index.php" class="back-link">
    ← Kembali ke Daftar Produk
</a>

<div class="form-card">
    <h2>Tambah Produk 📦</h2>
    <p>Masukkan informasi produk baru ke persediaan GlowMart.</p>

    <?php if ($message !== ''): ?>
        <div class="form-message">
            <?= e($message) ?>
        </div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-grid">
            <div class="form-group">
                <label for="sku">SKU Produk *</label>
                <input
                    type="text"
                    id="sku"
                    name="sku"
                    maxlength="100"
                    value="<?= e($sku) ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="name">Nama Produk *</label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    maxlength="255"
                    value="<?= e($name) ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="category_id">Kategori *</label>
                <select id="category_id" name="category_id" required>
                    <option value="">-- Pilih Kategori --</option>
                    <?php foreach ($categories as $category): ?>
                        <option
                            value="<?= (int) $category['id'] ?>"
                            <?= (string) $category_id === (string) $category['id']
                                ? 'selected' : '' ?>
                        >
                            <?= e($category['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="price">Harga Jual (Rp) *</label>
                <input
                    type="number"
                    id="price"
                    name="price"
                    min="0"
                    step="any"
                    value="<?= e($price) ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="stock">Stok Awal *</label>
                <input
                    type="number"
                    id="stock"
                    name="stock"
                    min="0"
                    step="1"
                    value="<?= e($stock) ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="minimum_stock">Minimum Stok *</label>
                <input
                    type="number"
                    id="minimum_stock"
                    name="minimum_stock"
                    min="0"
                    step="1"
                    value="<?= e($minimum_stock) ?>"
                    required
                >
            </div>

            <div class="full-width">
                <h3>Supplier Produk</h3>
                <p class="help-text">
                    Pilih satu atau beberapa supplier. Harga supplier boleh
                    dikosongkan jika belum diketahui.
                </p>

                <div class="supplier-list">
                    <?php if (empty($suppliers)): ?>
                        <p>Belum ada supplier. Tambahkan supplier terlebih dahulu.</p>
                    <?php else: ?>
                        <?php foreach ($suppliers as $supplier): ?>
                            <?php
                            $sid = (int) $supplier['id'];
                            $checked = in_array($sid, $supplier_ids, true);
                            $supplierPrice = $supplier_prices[$sid] ?? '';
                            ?>
                            <div class="supplier-row">
                                <input
                                    type="checkbox"
                                    id="supplier_<?= $sid ?>"
                                    name="supplier_ids[]"
                                    value="<?= $sid ?>"
                                    <?= $checked ? 'checked' : '' ?>
                                >

                                <label for="supplier_<?= $sid ?>">
                                    <?= e($supplier['name']) ?>
                                </label>

                                <input
                                    type="number"
                                    name="supplier_prices[<?= $sid ?>]"
                                    min="0"
                                    step="0.01"
                                    placeholder="Harga supplier (Rp)"
                                    aria-label="Harga dari <?= e($supplier['name']) ?>"
                                    value="<?= e($supplierPrice) ?>"
                                >
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">
                Simpan Produk
            </button>

            <a href="index.php" class="btn btn-light">Batal</a>
        </div>
    </form>
</div>

</main>
</body>
</html>
