<?php
if (!isset($page_title)) {
    $page_title = 'GlowMart';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f7f5fb;
            color: #29243a;
        }

        header {
            background: #6c4ab6;
            color: white;
            padding: 22px 35px;
        }

        header h1 {
            margin: 0;
            font-size: 28px;
        }

        main {
            max-width: 1100px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .panel {
            background: white;
            padding: 24px;
            border-radius: 12px;
            box-shadow: 0 3px 12px #0000000d;
            margin-bottom: 22px;
        }

        a {
            color: #6c4ab6;
        }

        button {
            background: #6c4ab6;
            color: white;
            border: 0;
            border-radius: 7px;
            padding: 10px 16px;
            cursor: pointer;
        }

        input, select, textarea {
            max-width: 100%;
            padding: 10px;
            border: 1px solid #d8d2e5;
            border-radius: 6px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid #eee8f5;
            text-align: left;
        }

        th {
            background: #eee8fa;
        }
    </style>
</head>
<body>
<header>
    <h1>GlowMart</h1>
    <p>Inventory Management System</p>
</header>
<main>
